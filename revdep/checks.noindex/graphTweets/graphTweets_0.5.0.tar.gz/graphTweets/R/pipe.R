#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

#' @importFrom zeallot %<-%
#' @export
zeallot::`%<-%`