library(testthat)
library(carbonate)

test_check("carbonate")
